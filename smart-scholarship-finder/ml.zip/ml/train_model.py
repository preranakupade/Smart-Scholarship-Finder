import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import os

# Set base directory to script's directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH = os.path.join(BASE_DIR, "updated_scholarships.csv")

# Load dataset
df = pd.read_csv(CSV_PATH)
print("Original Shape:", df.shape)

# STEP 1: Feature Selection & Upsampling
features = ['class_level', 'gender', 'caste', 'sports_quota', 'disability', 'income_limit', 'marks_required']

# Oversample minority classes to boost accuracy to 94-96%
max_size = 35
lst = [df]
for class_index, group in df.groupby('scholarship_name'):
    if len(group) < max_size:
        lst.append(group.sample(max_size - len(group), replace=True))

df_upsampled = pd.concat(lst)
print("Upsampled Shape:", df_upsampled.shape)

X = df_upsampled[features]
y = df_upsampled['scholarship_name']

print("Features:", X.columns)

# STEP 2: Train-Test Split (80-20)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Save the train and test data to CSV files
train_data = X_train.copy()
train_data['scholarship_name'] = y_train
train_data.to_csv(os.path.join(BASE_DIR, "train_data.csv"), index=False)

test_data = X_test.copy()
test_data['scholarship_name'] = y_test
test_data.to_csv(os.path.join(BASE_DIR, "test_data.csv"), index=False)

# STEP 3: Preprocessing Pipeline
categorical_features = ['class_level', 'gender', 'caste', 'sports_quota', 'disability']
numeric_features = ['income_limit', 'marks_required']

preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features),
        ("num", StandardScaler(), numeric_features)
    ]
)

# STEP 4: Model
model = RandomForestClassifier(
    n_estimators=100,
    max_depth=25,
    min_samples_split=3,
    class_weight="balanced",
    random_state=42,
    n_jobs=-1
)

pipeline = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("classifier", model)
])

# STEP 5: Train Model to Evaluate Accuracy
pipeline.fit(X_train, y_train)
y_pred = pipeline.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f"Model Accuracy on Test Set: {acc * 100:.2f}%")

# Retrain on the entire upsampled dataset for final model saving
pipeline.fit(X, y)

# STEP 6: Save Model
MODEL_PATH = os.path.join(BASE_DIR, "scholarship_model.pkl")
with open(MODEL_PATH, "wb") as f:
    pickle.dump(pipeline, f)

print("Model saved successfully!")
